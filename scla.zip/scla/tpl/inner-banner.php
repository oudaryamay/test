<div class="innrpgbannr">
	<?php
	if(! is_single() && !is_shop()){
	$featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); 
	if ($featured_img_url != null) {
	echo '<img src="'.esc_url($featured_img_url).'" alt="" border="0">';
	} else {
	echo '<img src="'.get_template_directory_uri().'/assets/images/inner-banner.jpg" alt="" border="0">';
	}
	} elseif( is_single()) {
	$event_banner = get_post_meta(get_the_ID(), '_scla_event_details_banner', true);
    if($event_banner != null) {
    echo '<img src="'.$event_banner.'" alt="" border="0">';	
	} else {
	echo '<img src="'.get_template_directory_uri().'/assets/images/inner-banner.jpg" alt="" border="0">';	
	}
	} elseif( is_shop()) {
	$shop_img_url = get_the_post_thumbnail_url(107,'full');
	if ($shop_img_url != null) {
	echo '<img src="'.esc_url($shop_img_url).'" alt="" border="0">';
	} else {
	echo '<img src="'.get_template_directory_uri().'/assets/images/inner-banner.jpg" alt="" border="0">';
	} 	
	} else {
	echo '<img src="'.get_template_directory_uri().'/assets/images/inner-banner.jpg" alt="" border="0">';		
	}
	?>
	<div class="bnnrtxtwrap">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
				<div class="bnnrcntarea">
				<?php
				$ano_title = get_post_meta(get_the_ID(), '_scla_page_title', true);
				$desc = get_post_meta(get_the_ID(), '_scla_page_short_description', true);

				if (! is_shop()) {
				if ($ano_title != null){
					echo $ano_title;
				} else {
					echo get_the_title(); 
				}
				} else {
				echo 'Events';
				}
				if(is_author()){
				$curauth = (isset($_GET['author_name'])) ? get_user_by('slug', $author_name) : get_userdata(intval($author));
				$id = $curauth->ID;
				$first_name =  get_user_meta($id, 'first_name', true);
              	$last_name =  get_user_meta($id, 'last_name', true);
              	echo $name = $first_name.' '.$last_name;
				}
				if($desc != null):
				echo '<p>'.$desc.'</p>';
				endif;
				?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!-- innr banner closed -->