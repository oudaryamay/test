<?php
$first_name  = $_REQUEST['first_name'];
$last_name   = $_REQUEST['last_name'];
$firm 		 = $_REQUEST['firm'];
$area_of_law = $_REQUEST['area_of_law'];
?>
<div class="srchfiltrarea">
    <button class="btn btn-block searchMobBtn">SEARCH MEMBERS <i class="fa fa-search"></i></button>
<div class="fltrarea">
  <form role="search" class="form-inline" name="user_search" method="post" action="<?php echo home_url( '/search-user' ); ?>">
    <div class="fldcol col-1">
        <input type="text" class="form-control" name="first_name" placeholder="First Name" value="<?php echo $first_name; ?>">
    </div>
    <div class="fldcol col-1">
       <input type="text" class="form-control" name="last_name" placeholder="Last Name" value="<?php echo $last_name; ?>">
    </div>
    <div class="fldcol col-1">
       <input type="text" class="form-control" name="firm" placeholder="Firm" value="<?php echo $firm; ?>">
    </div>
    <div class="fldcol col-2">
    	<select class="orderby form-control" name="area_of_law">
    		<option value="" selected="selected">Area Of Law</option>
    		<option <?php echo $status=$area_of_law == 'Anti-Discrimination' ? ' selected="selected"' : ''; ?> value="Anti-Discrimination">Anti-Discrimination</option>
    		<option <?php echo $status=$area_of_law == 'Asbestos Disease Compensation' ? ' selected="selected"' : ''; ?> value="Asbestos Disease Compensation">Asbestos Disease Compensation</option>
    		<option <?php echo $status=$area_of_law == 'Aviation' ? ' selected="selected"' : ''; ?> value="Aviation">Aviation</option>
    		<option <?php echo $status=$area_of_law == 'Build Unit/Body Corp / Strata Title' ? ' selected="selected"' : ''; ?> value="Build Unit/Body Corp / Strata Title">Build Unit/Body Corp / Strata Title</option>
    		<option <?php echo $status=$area_of_law == 'Building/Construction' ? ' selected="selected"' : ''; ?> value="Building/Construction">Building/Construction</option>
    		<option <?php echo $status=$area_of_law == 'Civil Litigation' ? ' selected="selected"' : ''; ?> value="Civil Litigation">Civil Litigation</option>
    		<option <?php echo $status=$area_of_law == 'Commercial' ? ' selected="selected"' : ''; ?> value="Commerical">Commercial</option>
    		<option <?php echo $status=$area_of_law == 'Company' ? ' selected="selected"' : ''; ?> value="Company">Company</option>
    		<option <?php echo $status=$area_of_law == 'Conveyance-Commercial/Leasing' ? ' selected="selected"' : ''; ?> value="Conveyance-Commercial/Leasing">Conveyance-Commercial/Leasing</option>
    		<option <?php echo $status=$area_of_law == 'Conveyance-Residential' ? ' selected="selected"' : ''; ?> value="Conveyance-Residential">Conveyance-Residential</option>
    		<option <?php echo $status=$area_of_law == 'Criminal' ? ' selected="selected"' : ''; ?> value="Criminal">Criminal</option>
    		<option <?php echo $status=$area_of_law == 'Elder Law/Aged' ? ' selected="selected"' : ''; ?> value="Elder Law/Aged">Elder Law/Aged</option>
    		<option <?php echo $status=$area_of_law == 'Family Law' ? ' selected="selected"' : ''; ?> value="Family Law">Family Law</option>
    		<option <?php echo $status=$area_of_law == 'Finance and Securities' ? ' selected="selected"' : ''; ?> value="Finance and Securities">Finance and Securities</option>
    		<option <?php echo $status=$area_of_law == 'Franchising' ? ' selected="selected"' : ''; ?> value="Franchising">Franchising</option>
    		<option <?php echo $status=$area_of_law == 'Immigration/Citizenship' ? ' selected="selected"' : ''; ?> value="Immigration/Citizenship">Immigration/Citizenship</option>
    		<option <?php echo $status=$area_of_law == 'Industrial Relations/Employment' ? ' selected="selected"' : ''; ?> value="Industrial Relations/Employment">Industrial Relations/Employment</option>
    		<option <?php echo $status=$area_of_law == 'Insolvency' ? ' selected="selected"' : ''; ?> value="Insolvency">Insolvency</option>
    		<option <?php echo $status=$area_of_law == 'Insurance' ? ' selected="selected"' : ''; ?> value="Insurance">Insurance</option>
    		<option <?php echo $status=$area_of_law == 'Intellectual Property/Copyright' ? ' selected="selected"' : ''; ?> value="Intellectual Property/Copyright">Intellectual Property/Copyright</option>
    		<option <?php echo $status=$area_of_law == 'Intellectual Property/Franchising' ? ' selected="selected"' : ''; ?> value="Intellectual Property/Franchising">Intellectual Property/Franchising</option>
    		<option <?php echo $status=$area_of_law == 'Landlord &amp; Tenant' ? ' selected="selected"' : ''; ?> value="Landlord &amp; Tenant">Landlord &amp; Tenant</option>
    		<option <?php echo $status=$area_of_law == 'Local Government/TownPlanning/Environmental' ? ' selected="selected"' : ''; ?> value="Local Government/TownPlanning/Environmental">Local Government/TownPlanning/Environmental</option>
    		<option <?php echo $status=$area_of_law == 'Music Arts and Entertainment' ? ' selected="selected"' : ''; ?> value="Music Arts and Entertainment">Music Arts and Entertainment</option>
    		<option <?php echo $status=$area_of_law == 'Personal Injury/Work Cover/Com Care' ? ' selected="selected"' : ''; ?> value="Personal Injury/Work Cover/Com Care">Personal Injury/Work Cover/Com Care</option>
    		<option <?php echo $status=$area_of_law == 'Professional Negligence-Medical Negligence' ? ' selected="selected"' : ''; ?> value="Professional Negligence-Medical Negligence">Professional Negligence-Medical Negligence</option>
    		<option <?php echo $status=$area_of_law == 'Professional Negligence-General' ? ' selected="selected"' : ''; ?> value="Professional Negligence-General">Professional Negligence-General</option>
    		<option <?php echo $status=$area_of_law == 'Retirement Villages/Manufactured Home Parks' ? ' selected="selected"' : ''; ?> value="Retirement Villages/Manufactured Home Parks">Retirement Villages/Manufactured Home Parks</option>
    		<option <?php echo $status=$area_of_law == 'Rural /Farming' ? ' selected="selected"' : ''; ?> value="Rural /Farming">Rural /Farming</option>
    		<option <?php echo $status=$area_of_law == 'Small Business' ? ' selected="selected"' : ''; ?> value="Small Business">Small Business</option>
    		<option <?php echo $status=$area_of_law == 'Sports' ? ' selected="selected"' : ''; ?> value="Sports">Sports</option>
    		<option <?php echo $status=$area_of_law == 'Student' ? ' selected="selected"' : ''; ?> value="Student">Student</option>
    		<option <?php echo $status=$area_of_law == 'Succession/Will/Probate/Estate' ? ' selected="selected"' : ''; ?> value="Succession/Will/Probate/Estate">Succession/Will/Probate/Estate</option>
    		<option <?php echo $status=$area_of_law == 'Superannuation/Trusts' ? ' selected="selected"' : ''; ?> value="Superannuation/Trusts">Superannuation/Trusts</option>
    	</select>
    </div>
    <div class="fldcol col-3">
       <input type="submit" class="btn btn-block applyFliterBtn" value="APPLY">
    </div>
  </form>
</div>
</div>

<?php
$args1  =  array (
		'role__not_in' => 'Administrator', 
        'meta_query' => array(
        'relation' => 'OR',
        array(
            'key'     => 'first_name',
            'value'   => $first_name,
            'compare' => '='
        ),
        array(
            'key'     => 'last_name',
            'value'   => $last_name,
            'compare' => '='
        ),
        array(
            'key'     => 'billing_company',
            'value'   => $firm,
            'compare' => '='
        ),
        array(
            'key'     => '_area_of_law',
            'value'   => $area_of_law,
            'compare' => 'LIKE'
        )
        )
    );

$args2  =  array (
		'role__not_in' => 'Administrator', 
        'meta_query' => array(
        'relation' => 'OR',
        array(
            'key'     => 'first_name',
            'value'   => $first_name,
            'compare' => '='
        ),
        array(
            'key'     => 'last_name',
            'value'   => $last_name,
            'compare' => '='
        ),
        array(
            'key'     => 'billing_company',
            'value'   => $firm,
            'compare' => '='
        )
        )
    );
	if($area_of_law != null) {
	$wp_user_query = new WP_User_Query($args1);
	} else {
	$wp_user_query = new WP_User_Query($args2);	
	}
    $wp_user_query->query_orderby = str_replace( 'user_login', 'wp_usermeta.meta_value', $wp_user_query->query_orderby );
    $wp_user_query->query();

    $users = $wp_user_query->get_results();
    /*
    echo '<pre>';
    print_r($users);
    echo '</pre>';
	*/
?>

<?php
  if ( $users != null ) { ?>
    <div class="memberTabArea searchpage">
  <table class="table table-striped">
    <!-- <thead>
      <tr>
        <th></th>
        <th></th>
        <th></th>
      </tr>
    </thead> -->
    <tbody>
<?php
  foreach($users as $u)
  {
  	$id=$u->ID;
     $user_nicename = get_user_meta($id, 'user_nicename', true);

	  $p_id =  get_user_meta($id, '_profile_image_id', true);
	  if ($p_id != null) {
	    $img_url =  wp_get_attachment_url( $p_id );
	  } else {
	    $img_url =  get_template_directory_uri().'/assets/images/executive-noimage.jpg';
	  }
	  $first_name =  get_user_meta($id, 'first_name', true);
	  $last_name =  get_user_meta($id, 'last_name', true);
	  $name = $first_name.' '.$last_name;

	  $p_ph_status = get_user_meta($id, '_phone_publis_status', true);
	  $phone = get_user_meta($id, 'billing_phone', true);

	  $firm = get_user_meta($id, 'billing_company', true);

	  $p_e_status = get_user_meta($id, '_email_publis_status', true);
	  $email = $u->user_email;
 	  ?>
		  <tr>
                <td><a href="<?php echo get_author_posts_url( $id, $user_nicename ); ?>"><img src="<?php echo $img_url; ?>"></a></td>
                <td>
                <label>NAME</label>
                <p class="name"><?php echo $name; ?></p>
                <?php if ( $p_ph_status == 1 && $phone != null ) :
                echo '<p class="iconText"><i class="fa fa-phone"></i> '.$phone.'</p>';
                endif; 
                ?>
                </td>
                <td>
                <label>FIRM</label>
                <p class="name"><?php echo $firm; ?></p>
                <?php
                if ( $p_e_status == 1 && $email != null ) :
                echo '<p class="iconText"><i class="fa fa-envelope-o"></i> '.$email.'</p>';
                endif;
                ?>
                </td>
              </tr>
	  <?php

  } ?>
  </tbody>
</table>
</div>

 <?php
} else {
	echo '<br><p>No member found from your search criteria.</p>';
}
?>
