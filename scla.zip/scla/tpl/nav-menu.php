<header>
	<div class="hdrTopStrp">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<h1 class="logo">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="SCLA"><img src="<?php echo ot_get_option('_scla_header_logo'); ?>" alt="SCLA logo" title="SCLA"></a>
					</h1>
				</div>
				<div class="col-md-8 text-right">
					<a href="<?php echo site_url(); ?>/become-a-member" class="btn">BECOME A MEMBER <i class="fa fa-angle-right" aria-hidden="true"></i></a>
					<ul class="hdrlink">
						<?php
						if ( is_user_logged_in() ) {
						echo '<li><a href="'.site_url().'/my-account">My Account</a></li>';
						} else {
						echo '<li><a href="'.site_url().'/my-account">Login</a></li>';	
						}
						?>
						<li><a href="<?php echo site_url(); ?>/cart"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/cart-icon.png" alt="" border="0"> (<?php echo WC()->cart->get_cart_contents_count(); $txt = (WC()->cart->get_cart_contents_count() > 1) ? 'items' : 'item'; echo '&nbsp;'.$txt; ?>)</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div><!-- top section closed -->
	<div class="hdrBtmStrp">
		<div class="container">
			<div class="row">
				<div class="col-md-10 pull-right text-right">
					<nav class="cssmenu lineMenu">
					  <?php
					  	wp_nav_menu( array(
						    'theme_location' => 'main-menu',
						    'container'		 => false,
						    'container_class'=> '',
						    'container_id'	 => '',
						) );
					  ?>
					</nav><!-- cssmenu tag closed -->
				</div>
			</div>
		</div>
	</div><!-- bottom section closed -->
</header><!-- header closed -->