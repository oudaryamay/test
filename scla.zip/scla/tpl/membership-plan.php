
			<?php
			$args = array( 'post_type' => 'product', 'posts_per_page' => -1, 'product_cat' => 'memberships', 'order' => 'ASC', 'orderby' => 'ID' );
	        $loop = new WP_Query( $args );
	        $counter=1;
	        while ( $loop->have_posts() ) : $loop->the_post(); global $product;
			?>
				<div class="col-md-4 col-sm-6 col-xs-12">
					<div class="imgcntblcktype2">
						<?php $prd_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');  ?>
						<div class="imgbox"><img src="<?php echo $prd_img_url; ?>" alt="" border="0"></div>
						<div class="contentbox">
							<h4><?php echo get_the_title(); ?></h4>
							<h3><?php echo $product->get_price_html(); ?></h3>
							<hr>
							<div class="memberShrtTxt">
								<?php echo get_field('join_page_small_content'); ?>
								<a href="void:javascript(0);" data-toggle="modal" class="expandCntBtn" data-target="#myModal<?php echo $counter;?>"><i class="fa fa-window-restore" aria-hidden="true"></i></a>
							</div>
							<?php //echo get_the_content(); ?>
							<div class="btnArea">
								<a href="<?php echo site_url() ?>/cart/?add-to-cart=<?php echo get_the_ID(); ?>" class="btn btn-md">ADD TO CART <i class="fa fa-angle-right" aria-hidden="true"></i></a>
							</div>
						</div>
					


				<!-- Modal open -->
				<div class="modal fade" id="myModal<?php echo $counter;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				  <div class="modal-dialog" role="document">
				    <div class="modal-content">
				      <div class="modal-header">
				        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				        <h4 class="modal-title"><?php echo get_the_title(); ?></h4>
				      </div>
				      <div class="modal-body">
				        <?php echo get_the_content(); ?>
				      </div>
				    </div>
				  </div>
				</div>
				<!-- Modal closed -->


				</div>
				</div><!-- block part closed -->

						 <?php 
						 $counter=$counter+1;
						endwhile; 
						?>
    		<?php wp_reset_query(); ?>
		