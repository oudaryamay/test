<div class="srchfiltrarea">
  <button class="btn btn-block searchMobBtn">SEARCH MEMBERS <i class="fa fa-search"></i></button>
<div class="fltrarea">
  <form role="search" class="form-inline" name="user_search" method="post" action="<?php echo home_url( '/search-user' ); ?>">
    <div class="fldcol col-1">
        <input type="text" class="form-control" name="first_name" placeholder="First Name">
    </div>
    <div class="fldcol col-1">
       <input type="text" class="form-control" name="last_name" placeholder="Last Name">
    </div>
    <div class="fldcol col-1">
       <input type="text" class="form-control" name="firm" placeholder="Firm">
    </div>
    <div class="fldcol col-2">
    	<select class="orderby form-control" name="area_of_law"><option value="" selected="selected">Area Of Law</option><option value="Anti-Discrimination">Anti-Discrimination</option><option value="Asbestos Disease Compensation">Asbestos Disease Compensation</option><option value="Aviation">Aviation</option><option value="Build Unit/Body Corp / Strata Title">Build Unit/Body Corp / Strata Title</option><option value="Building/Construction">Building/Construction</option><option value="Civil Litigation">Civil Litigation</option><option value="Commerical">Commercial</option><option value="Company">Company</option><option value="Conveyance-Commercial/Leasing">Conveyance-Commercial/Leasing</option><option value="Conveyance-Residential">Conveyance-Residential</option><option value="Criminal">Criminal</option><option value="Elder Law/Aged">Elder Law/Aged</option><option value="Family Law">Family Law</option><option value="Finance and Securities">Finance and Securities</option><option value="Franchising">Franchising</option><option value="Immigration/Citizenship">Immigration/Citizenship</option><option value="Industrial Relations/Employment">Industrial Relations/Employment</option><option value="Insolvency">Insolvency</option><option value="Insurance">Insurance</option><option value="Intellectual Property/Copyright">Intellectual Property/Copyright</option><option value="Intellectual Property/Franchising">Intellectual Property/Franchising</option><option value="Landlord &amp; Tenant">Landlord &amp; Tenant</option><option value="Local Government/TownPlanning/Environmental">Local Government/TownPlanning/Environmental</option><option value="Music Arts and Entertainment">Music Arts and Entertainment</option><option value="Personal Injury/Work Cover/Com Care">Personal Injury/Work Cover/Com Care</option><option value="Professional Negligence-Medical Negligence">Professional Negligence-Medical Negligence</option><option value="Professional Negligence-General">Professional Negligence-General</option><option value="Retirement Villages/Manufactured Home Parks">Retirement Villages/Manufactured Home Parks</option><option value="Rural /Farming">Rural /Farming</option><option value="Small Business">Small Business</option><option value="Sports">Sports</option><option value="Student">Student</option><option value="Succession/Will/Probate/Estate">Succession/Will/Probate/Estate</option><option value="Superannuation/Trusts">Superannuation/Trusts</option></select>
    </div>
    <div class="fldcol col-3">
       <input type="submit" class="btn btn-block applyFliterBtn" value="APPLY">
    </div>
  </form>
</div>
</div>

<!-- <div style="padding-bottom: 30px;"></div> -->
  <div class="memberTabArea">
  <ul class="nav nav-tabs">

   <li class="active"><a data-toggle="tab" href="#lifemember">Life Members</a></li>
   <li><a data-toggle="tab" href="#barristers">Barristers</a></li>
   <li><a data-toggle="tab" href="#solicitors"> Solicitors</a></li>
   <li><a data-toggle="tab" href="#associates"> Associates</a></li>
   <li><a data-toggle="tab" href="#students">  Students</a></li>

  </ul>

  <div class="tab-content">
    <?php $users = get_users( 'role=customer&role__not_in=administrator' ); ?>
    <div id="lifemember" class="tab-pane fade in active">
        <table class="table table-striped">
            <!-- <thead>
              <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
              </tr>
            </thead> -->
            <tbody>
         <?php

            foreach ( $users as $user ) {
            $id = $user->ID;
            $user_nicename = get_user_meta($id, 'user_nicename', true);

            $role = get_user_meta($id, '_customer_role');
              if($role[0]['life-member'] == 1) { 
              $p_id =  get_user_meta($id, '_profile_image_id', true);
              if ($p_id != null) {
                $img_url =  wp_get_attachment_url( $p_id );
              } else {
                $img_url =  get_template_directory_uri().'/assets/images/executive-noimage.jpg';
              }
              $first_name =  get_user_meta($id, 'first_name', true);
              $last_name =  get_user_meta($id, 'last_name', true);
              $name = $first_name.' '.$last_name;

              $p_ph_status = get_user_meta($id, '_phone_publis_status', true);
              $phone = get_user_meta($id, 'billing_phone', true);
            
              $firm = get_user_meta($id, 'billing_company', true);

              $p_e_status = get_user_meta($id, '_email_publis_status', true);
              $email = $user->user_email;

              $url = $user->user_url;

              $laws = get_user_meta($id, '_area_of_law');
              ?>
         
              <tr>
                <td><a href="<?php echo get_author_posts_url( $id, $user_nicename ); ?>"><img src="<?php echo $img_url; ?>"></a></td>
                <td>
                <label>NAME</label>
                <p class="name"><?php echo $name; ?></p>
                <?php if ( $p_ph_status == 1 && $phone != null ) :
                echo '<p class="iconText"><i class="fa fa-phone"></i> '.$phone.'</p>';
                endif; 
                ?>
                </td>
                <td>
                <label>FIRM</label>
                <p class="name"><?php echo $firm; ?></p>
                <?php
                if ( $p_e_status == 1 && $email != null ) :
                echo '<p class="iconText"><i class="fa fa-envelope-o"></i> '.$email.'</p>';
                endif;
                if($url != null) :
                echo '<p class="iconText"><i class="fa fa-globe"></i> '.$url.'</p>';
                endif;
                ?>
                </td>
                <td>
                <label>AREA OF LAW</label>
                <p>
                <?php 
                if($laws != null) :
                $total = count($laws[0]);
                if ($total >= 10){
                  $t = 10;
                } else {
                  $t = $total;
                }
                for ($x = 0; $x <= $t-1; $x++) {

                echo $laws[0][$x];
                if(! end($laws[0])) :
                echo '&nbsp;/&nbsp;';
                endif;
              
                }
                if($total > 10 ) {
                echo '...More';
                }
                endif;
                ?>
                </p>
               </td>
              </tr>
            
            
            <?php
              }
          }
          ?>
          </tbody>
          </table>
    </div>

    <div id="barristers" class="tab-pane fade">
             <table class="table table-striped">
            <!-- <thead>
              <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
              </tr>
            </thead> -->
            <tbody>
         <?php

            foreach ( $users as $user ) {
            $id = $user->ID;
            $user_nicename = get_user_meta($id, 'user_nicename', true);

            $role = get_user_meta($id, '_customer_role');
              if($role[0]['barristers'] == 1) { 
              $p_id =  get_user_meta($id, '_profile_image_id', true);
              if ($p_id != null) {
                $img_url =  wp_get_attachment_url( $p_id );
              } else {
                $img_url =  get_template_directory_uri().'/assets/images/executive-noimage.jpg';
              }
              $first_name =  get_user_meta($id, 'first_name', true);
              $last_name =  get_user_meta($id, 'last_name', true);
              $name = $first_name.' '.$last_name;

              $p_ph_status = get_user_meta($id, '_phone_publis_status', true);
              $phone = get_user_meta($id, 'billing_phone', true);
            
              $firm = get_user_meta($id, 'billing_company', true);

              $p_e_status = get_user_meta($id, '_email_publis_status', true);
              $email = $user->user_email;

              $url = $user->user_url;

              $laws = get_user_meta($id, '_area_of_law');
              ?>
         
              <tr>
                <td><a href="<?php echo get_author_posts_url( $id, $user_nicename ); ?>"><img src="<?php echo $img_url; ?>"></a></td>
                <td>
                <label>NAME</label>
                <p class="name"><?php echo $name; ?></p>
                <?php if ( $p_ph_status == 1 && $phone != null ) :
                echo '<p class="iconText"><i class="fa fa-phone"></i> '.$phone.'</p>';
                endif; 
                ?>
                </td>
                <td>
                <label>FIRM</label>
                <p class="name"><?php echo $firm; ?></p>
                <?php
                if ( $p_e_status == 1 && $email != null ) :
                echo '<p class="iconText"><i class="fa fa-envelope-o"></i> '.$email.'</p>';
                endif;
                if($url != null) :
                echo '<p class="iconText"><i class="fa fa-globe"></i> '.$url.'</p>';
                endif;
                ?>
                </td>
                <td>
                <label>AREA OF LAW</label>
                <p>
                <?php 
                if($laws != null) :
                $total = count($laws[0]);
                if ($total >= 10){
                  $t = 10;
                } else {
                  $t = $total;
                }
                for ($x = 0; $x <= $t-1; $x++) {

                echo $laws[0][$x];
                if(! end($laws[0])) :
                echo '&nbsp;/&nbsp;';
                endif;
              
                }
                echo '...More';
                endif;
                ?>
                </p>
               </td>
              </tr>
            
            
            <?php
              }
          }
          ?>
          </tbody>
          </table>
    </div>

    <div id="solicitors" class="tab-pane fade">
                   <table class="table table-striped">
            <!-- <thead>
              <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
              </tr>
            </thead> -->
            <tbody>
         <?php

            foreach ( $users as $user ) {
            $id = $user->ID;
            $user_nicename = get_user_meta($id, 'user_nicename', true);

            $role = get_user_meta($id, '_customer_role');
              if($role[0]['solicitors'] == 1) { 
              $p_id =  get_user_meta($id, '_profile_image_id', true);
              if ($p_id != null) {
                $img_url =  wp_get_attachment_url( $p_id );
              } else {
                $img_url =  get_template_directory_uri().'/assets/images/executive-noimage.jpg';
              }
              $first_name =  get_user_meta($id, 'first_name', true);
              $last_name =  get_user_meta($id, 'last_name', true);
              $name = $first_name.' '.$last_name;

              $p_ph_status = get_user_meta($id, '_phone_publis_status', true);
              $phone = get_user_meta($id, 'billing_phone', true);
            
              $firm = get_user_meta($id, 'billing_company', true);

              $p_e_status = get_user_meta($id, '_email_publis_status', true);
              $email = $user->user_email;

              $url = $user->user_url;

              $laws = get_user_meta($id, '_area_of_law');
              ?>
         
              <tr>
                <td><a href="<?php echo get_author_posts_url( $id, $user_nicename ); ?>"><img src="<?php echo $img_url; ?>"></a></td>
                <td>
                <label>NAME</label>
                <p class="name"><?php echo $name; ?></p>
                <?php if ( $p_ph_status == 1 && $phone != null ) :
                echo '<p class="iconText"><i class="fa fa-phone"></i> '.$phone.'</p>';
                endif; 
                ?>
                </td>
                <td>
                <label>FIRM</label>
                <p class="name"><?php echo $firm; ?></p>
                <?php
                if ( $p_e_status == 1 && $email != null ) :
                echo '<p class="iconText"><i class="fa fa-envelope-o"></i> '.$email.'</p>';
                endif;
                if($url != null) :
                echo '<p class="iconText"><i class="fa fa-globe"></i> '.$url.'</p>';
                endif;
                ?>
                </td>
                <td>
                <label>AREA OF LAW</label>
                <p>
                <?php 
                if($laws != null) :
                $total = count($laws[0]);
                if ($total >= 10){
                  $t = 10;
                } else {
                  $t = $total;
                }
                for ($x = 0; $x <= $t-1; $x++) {

                echo $laws[0][$x];
                if(! end($laws[0])) :
                echo '&nbsp;/&nbsp;';
                endif;
              
                }
                echo '...More';
                endif;
                ?>
                </p>
               </td>
              </tr>
            
            
            <?php
              }
          }
          ?>
          </tbody>
          </table>
    </div>

    <div id="associates" class="tab-pane fade">
                  <table class="table table-striped">
            <!-- <thead>
              <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
              </tr>
            </thead> -->
            <tbody>
         <?php

            foreach ( $users as $user ) {
            $id = $user->ID;
            $user_nicename = get_user_meta($id, 'user_nicename', true);

            $role = get_user_meta($id, '_customer_role');
              if($role[0]['associates'] == 1) { 
              $p_id =  get_user_meta($id, '_profile_image_id', true);
              if ($p_id != null) {
                $img_url =  wp_get_attachment_url( $p_id );
              } else {
                $img_url =  get_template_directory_uri().'/assets/images/executive-noimage.jpg';
              }
              $first_name =  get_user_meta($id, 'first_name', true);
              $last_name =  get_user_meta($id, 'last_name', true);
              $name = $first_name.' '.$last_name;

              $p_ph_status = get_user_meta($id, '_phone_publis_status', true);
              $phone = get_user_meta($id, 'billing_phone', true);
            
              $firm = get_user_meta($id, 'billing_company', true);

              $p_e_status = get_user_meta($id, '_email_publis_status', true);
              $email = $user->user_email;

              $url = $user->user_url;

              $laws = get_user_meta($id, '_area_of_law');
              ?>
         
              <tr>
                <td><a href="<?php echo get_author_posts_url( $id, $user_nicename ); ?>"><img src="<?php echo $img_url; ?>"></a></td>
                <td>
                <label>NAME</label>
                <p class="name"><?php echo $name; ?></p>
                <?php if ( $p_ph_status == 1 && $phone != null ) :
                echo '<p class="iconText"><i class="fa fa-phone"></i> '.$phone.'</p>';
                endif; 
                ?>
                </td>
                <td>
                <label>FIRM</label>
                <p class="name"><?php echo $firm; ?></p>
                <?php
                if ( $p_e_status == 1 && $email != null ) :
                echo '<p class="iconText"><i class="fa fa-envelope-o"></i> '.$email.'</p>';
                endif;
                if($url != null) :
                echo '<p class="iconText"><i class="fa fa-globe"></i> '.$url.'</p>';
                endif;
                ?>
                </td>
                <td>
                <label>AREA OF LAW</label>
                <p>
                <?php 
                if($laws != null) :
                $total = count($laws[0]);
                if ($total >= 10){
                  $t = 10;
                } else {
                  $t = $total;
                }
                for ($x = 0; $x <= $t-1; $x++) {

                echo $laws[0][$x];
                if(! end($laws[0])) :
                echo '&nbsp;/&nbsp;';
                endif;
              
                }
                echo '...More';
                endif;
                ?>
                </p>
               </td>
              </tr>
            
            
            <?php
              }
          }
          ?>
          </tbody>
          </table>
    </div>

    <div id="students" class="tab-pane fade">
                   <table class="table table-striped">
            <!-- <thead>
              <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
              </tr>
            </thead> -->
            <tbody>
         <?php

            foreach ( $users as $user ) {
            $id = $user->ID;
            $user_nicename = get_user_meta($id, 'user_nicename', true);

            $role = get_user_meta($id, '_customer_role');
              if($role[0]['students'] == 1) { 
              $p_id =  get_user_meta($id, '_profile_image_id', true);
              if ($p_id != null) {
                $img_url =  wp_get_attachment_url( $p_id );
              } else {
                $img_url =  get_template_directory_uri().'/assets/images/executive-noimage.jpg';
              }
              $first_name =  get_user_meta($id, 'first_name', true);
              $last_name =  get_user_meta($id, 'last_name', true);
              $name = $first_name.' '.$last_name;

              $p_ph_status = get_user_meta($id, '_phone_publis_status', true);
              $phone = get_user_meta($id, 'billing_phone', true);
            
              $firm = get_user_meta($id, 'billing_company', true);

              $p_e_status = get_user_meta($id, '_email_publis_status', true);
              $email = $user->user_email;

              $url = $user->user_url;

              $laws = get_user_meta($id, '_area_of_law');
              ?>
         
              <tr>
                <td><a href="<?php echo get_author_posts_url( $id, $user_nicename ); ?>"><img src="<?php echo $img_url; ?>"></a></td>
                <td>
                <label>NAME</label>
                <p class="name"><?php echo $name; ?></p>
                <?php if ( $p_ph_status == 1 && $phone != null ) :
                echo '<p class="iconText"><i class="fa fa-phone"></i> '.$phone.'</p>';
                endif; 
                ?>
                </td>
                <td>
                <label>FIRM</label>
                <p class="name"><?php echo $firm; ?></p>
                <?php
                if ( $p_e_status == 1 && $email != null ) :
                echo '<p class="iconText"><i class="fa fa-envelope-o"></i> '.$email.'</p>';
                endif;
                if($url != null) :
                echo '<p class="iconText"><i class="fa fa-globe"></i> '.$url.'</p>';
                endif;
                ?>
                </td>
                <td>
                <label>AREA OF LAW</label>
                <p>
                <?php 
                if($laws != null) :
                $total = count($laws[0]);
                if ($total >= 10){
                  $t = 10;
                } else {
                  $t = $total;
                }
                for ($x = 0; $x <= $t-1; $x++) {

                echo $laws[0][$x];
                if(! end($laws[0])) :
                echo '&nbsp;/&nbsp;';
                endif;
              
                }
                echo '...More';
                endif;
                ?>
                </p>
               </td>
              </tr>
            
            
            <?php
              }
          }
          ?>
          </tbody>
          </table>
    </div>

  </div>
</div>