<section class="section_block wlcmSection">
	<div class="container">
			<div class="row">
				<div class="col-md-7 col-sm-12 col-xs-12">
					<h3 class="heading_lg"><?php echo ot_get_option('_scla_home_left_heading'); ?></h3>
					<h4 class="heading_md color_red"><?php echo ot_get_option('_scla_home_left_subheading'); ?></h4>
					<ul class="itemlist">
						<?php
						$lists=ot_get_option('_scla_home_left_list'); 
						foreach($lists as $key=>$list){
						?>
						<li><?php echo $list['_scla_home_left_list_title']; ?></li>
						<?php } ?>
			        </ul>
				</div><!-- left part closed --> 

				<div class="col-md-5 col-sm-12 col-xs-12 wlcmpicsec">
					<div class="wlcmframe">
						<img src="<?php echo ot_get_option('_scla_home_right_image'); ?>" alt="" border="0">
					</div>
				</div><!-- right part closed -->
				

			</div>
		</div>	
</section><!-- welcome section ended -->