<div class="hmbnnr">
	<div class="slider home-slider">
		<?php
		$args = array(
	      'post_type' => 'scla-slider',
	       );
		$slider_query = new WP_Query( $args );
        if ( $slider_query->have_posts() ) :
        while ( $slider_query->have_posts() ) : $slider_query->the_post();
        $slider_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); 
		?>
		<li>
		  <img src="<?php echo $slider_img_url; ?>" alt="" border="0">
		    <div class="homeBannerCaption fadeInLeft">
		      <div class="container">
		          <div class="homeBannerCaptionInner">
		              <h3><?php echo get_the_title(); ?></h3>
		               <?php echo get_the_content(); ?>
		            </div>
		        </div>
		    </div>
		</li>
		<?php
		endwhile; 
     	endif; 
     	wp_reset_query();
        ?>
	</div>
</div><!-- home banner closed -->