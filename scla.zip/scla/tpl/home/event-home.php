<section class="section_block text-center ourevntsctn transition">
	<div class="container">
		<div class="row">
			<h3 class="heading_lg"><?php echo ot_get_option('_scla_home_event_title'); ?></h3>
				<ul class="slider event-slider">
					<?php
					$args = array(
				    'post_type' => 'product',
				    'posts_per_page' => -1,
				    'tax_query' => array(
				            array(
				                'taxonomy' => 'product_visibility',
				                'field'    => 'name',
				                'terms'    => 'featured',
				            ),
				        ),
				    );
					$loop = new WP_Query( $args );
					if ( $loop->have_posts() ) :
					    while ( $loop->have_posts() ) : $loop->the_post();
					$prd_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); 
					?>
				<a href="<?php echo get_the_permalink(); ?>">
					<li>
						<div class="imgcntblck">
							<div class="imgbox"><img src="<?php echo $prd_img_url; ?>" alt="" border="0"></div>
							<div class="cntprt">
								<h6><?php echo get_the_title(); ?></h6>
								<?php if (get_post_meta(get_the_ID(), '_scla_event_date', true) != null ) : ?>
								<p><label>Event Date:</label>
									<?php 
									$originaleDate = get_post_meta(get_the_ID(), '_scla_event_date', true);
									echo $newEDate = date("D, j M, Y - g:i a", strtotime($originaleDate)); 
									?></p>
								<?php endif; ?>
								
								<?php if (get_post_meta(get_the_ID(), '_scla_rsvp_date', true) != null ) : ?>
								<p><label>RSVP Date:</label>
									<?php 
									$originalreDate = get_post_meta(get_the_ID(), '_scla_rsvp_date', true);
									echo $newrDate = date("D, j M, Y - g:i a", strtotime($originalreDate));  
									?></p>
								<?php endif; ?>

								<?php if (get_post_meta(get_the_ID(), '_scla_address', true) != null ) : ?>
								<p><label class="full">Address:</label><?php echo get_post_meta(get_the_ID(), '_scla_address', true); ?></p>
							<?php endif; ?>
							</div>
						</div>
					</li><!-- block closed -->
				</a>
					<?php
					endwhile;
					endif;
					wp_reset_postdata();
					?>
				</ul><!-- full slider section closed -->
				<div class="col-md-12">
					<a href="<?php echo site_url(); ?>/shop" class="btn btn-md">VIEW ALL EVENTS <i class="fa fa-angle-right" aria-hidden="true"></i></a>
				</div>
		</div>
	</div>
</section><!-- service section full closed -->
