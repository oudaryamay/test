<section class="section_block text-center executivesctn">
	<div class="container">
		<div class="row">
			<h3 class="heading_lg"><?php echo ot_get_option('_scla_home_member_heading'); ?></h3>
			<ul class="slider executive-slider">
				<?php
				$e_users = get_users( 'role=customer&role__not_in=administrator' );
				/*
				echo '<pre>';
				print_r($e_users);
				echo '</pre>';
				*/
				foreach ( $e_users as $e_user ) {
				      $id = $e_user->ID;
				      $member = get_user_meta( $id, '_member_type', true);
				      if($member['executive_member'] == 1) { 
				      $p_id =  get_user_meta($id, '_profile_image_id', true);
				      if ($p_id != null) {
				      	$img_url =  wp_get_attachment_url( $p_id );
				      } else {
				      	$img_url =  get_template_directory_uri().'/assets/images/executive-noimage.jpg';
				      }
				      $first_name =  get_user_meta($id, 'first_name', true);
				      $last_name =  get_user_meta($id, 'last_name', true);
				      $name = $first_name.' '.$last_name;
				      $designation = get_user_meta($id, '_executive_member_designation', true);
				      $user_nicename = get_user_meta($id, 'user_nicename', true);
				      ?>
					<li>
					<a href="<?php echo get_author_posts_url( $id, $user_nicename ); ?>">
						<div class="executivebox">
							<div class="imgbox"><img src="<?php echo $img_url; ?>" alt="" border="0"></div>
							<div class="contbox">
								<div class="contnwrap">
									<h5><?php echo $name; ?><small><?php echo $designation; ?></small></h5>
								</div>
							</div>
						</div>
					</a>
					</li>	
						
					<?php
				      }
					}
					?>
			<li class="vwallexecutvbtn">
					<a href="<?php echo site_url(); ?>/members" class="btn">VIEW ALL MEMBERS <i class="fa fa-angle-right" aria-hidden="true"></i></a>
				</li>
			</ul><!-- slider closed -->

			<div class="col-md-12 executvmoblbtn">
				<a href="<?php echo site_url(); ?>/members" class="btn btn-md">VIEW ALL MEMBERS <i class="fa fa-angle-right" aria-hidden="true"></i></a>
			</div>
		</div>
	</div>
</section>