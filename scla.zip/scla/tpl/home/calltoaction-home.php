<section class="section_block membersctn">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="lftmembrsctn">
					<h3 class="heading_lg"><?php echo ot_get_option('_scla_home_calltoaction_heading'); ?></h3>
					<p><?php echo ot_get_option('_scla_home_calltoaction_subheading'); ?></p>
				</div>
				<div class="rgtmembrsctn">
					<div class="wrapscn">
						<a href="<?php echo site_url(); ?>/become-a-member" class="btn">BECOME A MEMBER <i class="fa fa-angle-right" aria-hidden="true"></i></a>

						<?php 
						if ( is_user_logged_in() ) {
						?>
						<?php }else {?>
						<span class="or">OR</span>
						<a href="<?php echo site_url(); ?>/my-account" class="btn btn-line">LOGIN <i class="fa fa-angle-right" aria-hidden="true"></i></a>
						<?php }?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section><!-- member section ended -->