<?php if(is_front_page()) { ?>
<section class="section_block text-center sponsorsctn">
	<div class="container">
		<div class="row">
			<h3 class="heading_lg"><?php echo ot_get_option('_scla_home_sponsor_heading'); ?></h3>
			<p class="heading_sub"><?php echo ot_get_option('_scla_home_sponsor_subheading'); ?></p>
			<ul class="slider sponsors-slider">
				<?php
				/*
				if ( function_exists( 'ot_get_option' ) ) {
				$images = explode( ',', ot_get_option( '_scla_home_sponsor_gallery', '' ) );
				    if ( ! empty( $images ) ) {
				foreach( $images as $id ) {
				    if ( ! empty( $id ) ) {
				$full_img_src = wp_get_attachment_image_src( $id, 'full' );
				    echo '<li><a href="#"><img src="'.$full_img_src[0].'" alt="" border="0"></a></li>';
				            }
				        }
				    }
				}
				*/
				?>
				<?php
				$args = array(
			      'post_type' => 'scla-sponsor',
			      'posts_per_page' => 14
			       );
				$sponsor_query = new WP_Query( $args );
		        if ( $sponsor_query->have_posts() ) :
		        while ( $sponsor_query->have_posts() ) : $sponsor_query->the_post();
		        $sponsor_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); 
		        $redirect_link=get_post_meta(get_the_ID(), '_scla_sponsor_redirect_link', true);
				
				if($redirect_link != null) {
				echo '<li><a target="_blank" href="'.$redirect_link .'"><img src="'.$sponsor_img_url.'" alt="" border="0"></a></li>';
				} else {
				echo '<li><a><img src="'.$sponsor_img_url.'" alt="" border="0"></a></li>';	
				}
			
				endwhile; 
		     	endif; 
		     	wp_reset_query();
		        ?>
			</ul>
		</div>
	</div>
</section><!-- sponsor section closed -->
<?php } else { ?>
<section class="section_block text-center sponsorsctn">
	<div class="container">
		<div class="row">
				<ul class="slider sponsors-slider">
				<?php
				$args = array(
			      'post_type' => 'scla-sponsor',
			      'posts_per_page' => -1
			       );
				$sponsor_query = new WP_Query( $args );
		        if ( $sponsor_query->have_posts() ) :
		        while ( $sponsor_query->have_posts() ) : $sponsor_query->the_post();
		        $sponsor_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); 
		        $redirect_link=get_post_meta(get_the_ID(), '_scla_sponsor_redirect_link', true);
				
				if($redirect_link != null) {
				echo '<li><a target="_blank" href="'.$redirect_link .'"><img src="'.$sponsor_img_url.'" alt="" border="0"></a></li>';
				} else {
				echo '<li><a><img src="'.$sponsor_img_url.'" alt="" border="0"></a></li>';	
				}
			
				endwhile; 
		     	endif; 
		     	wp_reset_query();
		        ?>
			</ul>
		</div>
	</div>
</section><!-- sponsor section closed -->
<?php } ?>