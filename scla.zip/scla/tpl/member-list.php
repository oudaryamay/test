  <?php 
  $args = array(
    'hide_empty' => false
  );
  $terms = get_terms( 'member_category', $args); 
  ?>
  <ul class="nav nav-tabs">
     <?php
     if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
      $i=1;
    foreach ( $terms as $term ) {
      $class=($i==1) ? 'active' : '';
    echo '<li class="'.$class.'"><a data-toggle="tab" href="#'.$term->slug.'"> '.$term->name.'</a></li>';
      $i++;
      }
    }
    ?>
  </ul>

  <div class="tab-content">

      <?php
        if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
        $i=1;
        foreach ( $terms as $term ) {
          $class=($i==1) ? 'in active' : '';
         ?>
            <div id="<?php echo $term->slug; ?>" class="tab-pane fade <?php echo $class; ?>">
            <?php
                $args = array(
                  'post_type' => 'scla-team',
                  'posts_per_page' => -1,
                  'tax_query' => array(
                    array(
                      'taxonomy' => 'member_category',
                      'field'    => 'slug',
                      'terms'    => $term->slug,
                    ),
                  ),
                );
                global $post;
                $member_qry = new WP_Query( $args );
                if ( $member_qry->have_posts() ) :
                  while ( $member_qry->have_posts() ) : $member_qry->the_post();
                $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');

                if ($featured_img_url != null) {
                $img = '<img src="'.esc_url($featured_img_url).'" alt="" border="0">';
                } else {
                $img = '<img src="'.get_template_directory_uri().'/assets/images/executive-noimage.jpg" alt="" border="0">';
                }

                $phone_state=get_post_meta(get_the_ID(), '_scla_team_phone_onoff', true);
                $phone=get_post_meta(get_the_ID(), '_scla_team_phone', true);

                $firm=get_post_meta(get_the_ID(), '_scla_team_firm', true);

                $email_state=get_post_meta(get_the_ID(), '_scla_team_email_onoff', true);
                $email=get_post_meta(get_the_ID(), '_scla_team_email', true);

                $url=get_post_meta(get_the_ID(), '_scla_team_website', true);

                $areas=get_post_meta(get_the_ID(), '_scla_team_areas_of_law', true);
                ?>
                <table class="table table-striped">
                          <thead>
                            <tr>
                              <th></th>
                              <th></th>
                              <th></th>
                              <th></th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td><?php echo $img; ?></td>
                              <td>
                              <p><span>NAME</span></p>
                              <p><?php echo get_the_title(); ?></p>
                              <?php if ( $phone_state == 'on' && $phone != null ) :
                              echo '<p>Phone: '.$phone.'</p>';
                              endif; 
                              ?>
                              </td>
                              <td>
                              <p><span>FIRM</span></p>
                              <p><?php echo $firm; ?></p>
                              <?php
                              if ( $email_state == 'on' && $email != null ) :
                              echo '<p>Email: '.$email.'</p>';
                              endif;
                              if($url != null) :
                              echo '<p>Website: '.$url.'</p>';
                              endif;
                              ?>
                              </td>
                              <td>
                              <p><span>AREA OF LAW</span></p>
                              <p>
                              <?php 
                              if($areas != null) :
                              foreach($areas as $area) :
                              echo $area['_scla_team_areas_of_law_item'].'/';
                              endforeach;
                              endif;
                              ?>
                              </p>
                             </td>
                            </tr>
                          </tbody>
                        </table>
                   
              <?php endwhile;
                   else : ?>
                <p><?php esc_html_e( 'Sorry, no member found.' ); ?></p>
              <?php endif; ?>
            
            </div>
            <?php
              $i++;
              }
            }
            ?>
  </div>
