<?php get_header();
		$user = get_userdata( $id );

		$p_id =  get_user_meta($id, '_profile_image_id', true);
		if ($p_id != null) {
		$img_url =  wp_get_attachment_url( $p_id );
		} else {
		$img_url =  get_template_directory_uri().'/assets/images/executive-noimage.jpg';
		}

      $first_name =  get_user_meta($id, 'first_name', true);
      $last_name =  get_user_meta($id, 'last_name', true);
      $name = $first_name.' '.$last_name; 

      $role = get_user_meta($id, '_customer_role');

      $member = get_user_meta($id, '_member_type', true);

	  $p_ph_status = get_user_meta($id, '_phone_publis_status', true);
	  $phone = get_user_meta($id, 'billing_phone', true);

	  $p_e_status = get_user_meta($id, '_email_publis_status', true);
	  $email = $user->user_email;

	  $url = $user->user_url;

	  $description =  get_user_meta($id, 'description', true);

	  $firm = get_user_meta($id, 'billing_company', true);

	  $laws = get_user_meta($id, '_area_of_law');

       ?>
	<div class="col-sm-4">
		<div class="membrprflpic">
			<img src="<?php echo $img_url ; ?>" alt="" border="0">
		</div>
	</div><!-- left part closed -->
	<div class="col-sm-8 memberdetail">
		<h3 class="membername"><?php echo $name; ?></h3>
		<h4 class="membersubname">

		<?php
		  if($role[0]['life-member'] == 1){
		  	echo 'Life Member '; 
		  }
		  if($role[0]['barristers'] == 1){
		  	echo 'Barristers '; 
		  }
		  if($role[0]['solicitors'] == 1){
		  	echo 'Solicitors ';
		  }
		  if($role[0]['associates'] == 1){
		  	echo 'Associates ';
		  }
		  if($role[0]['students'] == 1){
		  	echo 'Students ';
		  }
		?>
		</h4>
		<h4 class="membersubname designation">
		<?php
		if($member['executive_member'] == 1) {
			echo 'Executive Member ';
		}
		if($member['commission_member'] == 1) {
			echo 'Commission Member ';
		}
		if($member['member'] == 1) {
			echo 'Member ';
		}

		?>
		</h4>
		
		<ul class="meminfolist">
			<?php if ( $p_ph_status == 1 && $phone != null ) : ?>
			<li><a href="tel:<?php echo $phone; ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/phone-icon.png" alt="" border="0"><span><?php echo $phone; ?></span></a></li>
			<?php endif; ?>
			<?php if ( $p_e_status == 1 && $email != null ) : ?>
			<li><a href="mailto:<?php echo $email; ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/envelop-icon.png" alt="" border="0"><span><?php echo $email; ?></span></a></li>
			<?php endif; ?>
			<?php if ($url != null): ?>
			<li><a target="_blank" href="<?php echo $url; ?>"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/glob-icon.png" alt="" border="0"><span><?php echo $url; ?></span></a></li>
		<?php endif; ?>
		</ul>
		<?php if($description != null) : ?>
		<p><?php echo $description ; ?></p>
		<?php endif; ?>
		
		<?php if($firm != null) : ?>
		<div class="infoblck">
			<?php echo $firm; ?>
		</div>
		<?php endif; ?>
		<?php if($laws != null) : ?>
		<div class="infoblck border-none">
			<label>AREAS OF LAW</label>
				<ul>
				<?php 
				$total = count($laws[0]);
				for ($x = 0; $x <= $total-1; $x++) {
                echo '<li>'.$laws[0][$x].'</li>';
                }
				?>
			</ul>
		</div>
	<?php endif; ?>
	</div><!-- right part closed -->
<?php get_footer(); ?>