<?php
if (! is_front_page()) {
get_template_part( 'tpl/wrapper', 'end' );
}
?>
<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="ftrlogo"><a href="#"><img src="<?php echo ot_get_option('_scla_footer_logo'); ?>" alt="" border="0"></a></div>
			 	<?php
				  	wp_nav_menu( array(
					    'theme_location' => 'footer-menu',
					    'items_wrap'	 => '<ul class="ftrlink">%3$s</ul>',
					    'container'		 => false,
					    'container_class'=> '',
					    'container_id'	 => '',
					) );
				  ?>
			</div>
			<div class="col-md-6 copywrite">© Copyright <?php echo date('Y'); ?> <?php echo ot_get_option('_scla_footer_copyright'); ?></div>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>	
</body>
</html>