<?php
defined('ABSPATH') || exit;
add_action( 'admin_init', 'custom_meta_boxes' );

function custom_meta_boxes() {

$product_meta_box = array(
    'id'        => 'scla_product_meta_box',
    'title'     => 'Event Details',
    'desc'      => 'Details of event.',
    'pages'     => array( 'product' ),
    'context'   => 'normal',
    'priority'  => 'high',
    'fields'    => array(
        array(
                'id'          => '_scla_event_details_banner',
                'label'       => __( 'Event details page banner', 'scla' ),
                'desc'        => __( 'Event details page banner.', 'scla' ),
                'type'        => 'upload', 
             ),
         array(
                'id'          => '_scla_event_date',
                'label'       => __( 'Event Date', 'scla' ),
                'desc'        => __( 'Date of event.', 'scla' ),
                'type'        => 'date-time-picker',
                               
         ),
        array(
                'id'          => '_scla_rsvp_date',
                'label'       => __( 'RSVP Date', 'scla' ),
                'desc'        => __( 'Event RSVP date.', 'scla' ),
                'type'        => 'date-time-picker',
                                
         ),
        array(
                'id'          => '_scla_address',
                'label'       => __( 'Address', 'scla' ),
                'desc'        => __( 'Event address.', 'scla' ),
                'type'        => 'textarea-simple', 
                'rows'        => 3,
         ),

        array(
                'id'          => '_scla_event_details_reference',
                'label'       => __( 'Reference', 'scla' ),
                'desc'        => __( 'Reference of product content type.', 'scla' ),
                'type'        => 'text', 
             ),
        array(
                'id'          => '_scla_event_details_sponsors',
                'label'       => __( 'Sponsors', 'scla' ),
                'desc'        => __( 'Reference of Sponsors.', 'scla' ),
                'type'        => 'text', 
             ),
         array(
                'id'          => '_scla_event_details_cpd',
                'label'       => __( 'CPD points', 'scla' ),
                'desc'        => __( 'CPD points for this event.', 'scla' ),
                'type'        => 'text', 
             ),
         array(
                'id'          => '_scla_event_details_attendees',
                'label'       => __( 'User Reference', 'scla' ),
                'desc'        => __( 'User Reference.', 'scla' ),
                'type'        => 'text', 
             ),
         array(
                'id'          => '_scla_event_details_event_product_reference',
                'label'       => __( 'Reference', 'scla' ),
                'desc'        => __( 'Event reference or product reference.', 'scla' ),
                'type'        => 'text', 
             ),
    )
  );
$team_meta_box = array(
    'id'        => 'scla_team_meta_box',
    'title'     => 'Member Details',
    'desc'      => 'Details of member.',
    'pages'     => array( 'scla-team' ),
    'context'   => 'normal',
    'priority'  => 'high',
    'fields'    => array(
         array(
                'id'          => '_scla_team_designation',
                'label'       => __( 'Designation', 'scla' ),
                'desc'        => __( 'Member designation.', 'scla' ),
                'type'        => 'text',
                               
         ),
         array(
                'id'          => '_scla_team_phone_onoff',
                'label'       => __( 'Show phone no.', 'scla' ),
                'desc'        => __( 'Showing phone no. in member details page.', 'scla' ),
                'type'        => 'on-off',
                               
         ),
         array(
                'id'          => '_scla_team_phone',
                'label'       => __( 'Phone', 'scla' ),
                'desc'        => __( 'Member phone no.', 'scla' ),
                'type'        => 'text',
                'condition' => '_scla_team_phone_onoff:is(on)',
                               
         ),
         array(
                'id'          => '_scla_team_email_onoff',
                'label'       => __( 'Show email.', 'scla' ),
                'desc'        => __( 'Showing email in member details page.', 'scla' ),
                'type'        => 'on-off',
                               
         ),
         array(
                'id'          => '_scla_team_email',
                'label'       => __( 'Email', 'scla' ),
                'desc'        => __( 'Member email', 'scla' ),
                'type'        => 'text',
                'condition' => '_scla_team_email_onoff:is(on)',
                               
         ),
           array(
                'id'          => '_scla_team_website',
                'label'       => __( 'Website url', 'scla' ),
                'desc'        => __( 'Website url without http:// and www.', 'scla' ),
                'type'        => 'text',
                               
         ),
         array(
                'id'          => '_scla_team_firm',
                'label'       => __( 'Firm', 'scla' ),
                'desc'        => __( 'Firm name', 'scla' ),
                'type'        => 'text',
                               
         ),
         array(
        'id'          => '_scla_team_areas_of_law',
        'label'       => 'Areas of law',
        'type'        => 'list-item',
        'settings'    => array(
            array(
            'id'        => '_scla_team_areas_of_law_item',
            'label'     => 'Add areas of law item',
            'type'      => 'text',
 
            ),
        )
     ),
  )
);
$page_meta_box = array(
    'id'        => 'scla_page_meta_box',
    'title'     => 'Page Details',
    'desc'      => 'Details of page.',
    'pages'     => array( 'page' ),
    'context'   => 'normal',
    'priority'  => 'high',
    'fields'    => array(
         array(
                'id'          => '_scla_page_title',
                'label'       => __( 'Page title', 'scla' ),
                'desc'        => __( 'Page another title.', 'scla' ),
                'type'        => 'text',
                               
         ),
         array(
                'id'          => '_scla_page_short_description',
                'label'       => __( 'Page short description', 'scla' ),
                'desc'        => __( 'Short description of the page.', 'scla' ),
                'type'        => 'textarea',
                'rows'        => 2,
                               
         ),
    )
  );

$sponsor_meta_box = array(
    'id'        => 'scla_sponsor_meta_box',
    'title'     => 'Sponsor Details',
    'desc'      => 'Details of sponsor.',
    'pages'     => array( 'scla-sponsor' ),
    'context'   => 'normal',
    'priority'  => 'high',
    'fields'    => array(
         array(
                'id'          => '_scla_sponsor_redirect_link',
                'label'       => __( 'Redirect link', 'scla' ),
                'desc'        => __( 'Redirection link of sponsor.', 'scla' ),
                'type'        => 'text',
                               
         ),
    )
  );
ot_register_meta_box( $product_meta_box );
ot_register_meta_box( $team_meta_box );
ot_register_meta_box( $page_meta_box );
ot_register_meta_box( $sponsor_meta_box );
}
  
