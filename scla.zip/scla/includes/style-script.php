<?php
defined('ABSPATH') || exit;
/* Load Theme Essential Stylesheets & Script */
function scla_theme_styles()  { 
   /* Fontawesome library */ 
    wp_enqueue_style( 'font-awesome', get_stylesheet_directory_uri() . '/assets/fonts/fontawesome/font-awesome.min.css', array());
    /* Bootstrap library */ 
	  wp_enqueue_style( 'bootstrap', get_stylesheet_directory_uri() . '/assets/css/bootstrap.min.css', array());
     /* Plugin-style library */ 
    wp_enqueue_style( 'plugin-style', get_stylesheet_directory_uri() . '/assets/css/plugin-style.css', array());
      /* Custom style library */ 
    wp_enqueue_style( 'style', get_stylesheet_directory_uri() . '/assets/css/style.css', array());
	}
add_action( 'wp_enqueue_scripts', 'scla_theme_styles' );

function scla_theme_scripts() {
	/* jquery Library */
	//wp_enqueue_script('jQuery');
    /*jQuery library*/
  wp_enqueue_script( 'jquery-min', get_stylesheet_directory_uri() . '/assets/js/jquery-2.2.4.min.js', array(), '', false);
  wp_enqueue_script( 'bootstrap-min', get_stylesheet_directory_uri() . '/assets/js/bootstrap.min.js', array(), '', false);
    /*bootstrap library*/
  wp_enqueue_script( 'plugin-script', get_stylesheet_directory_uri() . '/assets/js/plugin-script.js', array(), '', false);
    /*owl carousel library*/
  wp_enqueue_script( 'custom', get_stylesheet_directory_uri() . '/assets/js/custom.js', array(), '', false);
     }
add_action( 'wp_enqueue_scripts', 'scla_theme_scripts' );