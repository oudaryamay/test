<?php
defined('ABSPATH') || exit;
add_action( 'after_setup_theme', 'scla_setup' );
function scla_setup()
{
add_theme_support( 'title-tag' );
add_theme_support( 'post-thumbnails' );
add_theme_support( 'woocommerce' );
register_nav_menus( array(
  'main-menu' => 'Header Main Menu',
  'footer-menu' => 'Footer Menu'
) );
}
add_filter('nav_menu_css_class' , 'special_nav_class' , 10 , 2);
function special_nav_class($classes, $item){
     if( in_array('current-menu-item', $classes) ){
             $classes[] = 'activeMenu ';
     }
     return $classes;
}
/*
 * This will hide the settings & documentation pages.
*/
add_filter( 'ot_show_pages', '__return_false' );
add_filter( 'ot_header_logo_link', 'custom_theme_option_icon');
 function custom_theme_option_icon(){
 return get_bloginfo('stylesheet_directory').'/includes/OB_Logo.png';
 }
 add_filter( 'ot_header_version_text', 'custom_theme_option_name');
 function custom_theme_option_name(){
  return "SCLA : Theme Option";
 }
add_filter( 'ot_theme_mode', '__return_true' );
add_filter( 'ot_show_new_layout', '__return_false' );

//fired before left side footer text is echoed.
add_filter('admin_footer_text', 'scla_footer_text');
//fired before right side footer text is echoed. Third parameter is just a indication of a version number, its values doesn't make any other sense.
add_filter('update_footer', 'scla_footer_version', 11);
 
//$default represents the existing text in the left side
function scla_footer_text($default) {
    //return the new footer text
    return '© '.date('Y').' SCLA, All Rights Reserve';
}
 
//$default represents the exisiting text in the right side
function scla_footer_version($default) {
    //return the new footer text
    return 'Version 1.0';
}

function homepage_edit_notice() {

    //only admin can see
    $user = wp_get_current_user();
    if ( ! in_array( 'administrator', $user->roles ) ) {
        return;
    }

    // Making sure notice only show for home page
    $id = get_the_id();
    if ( $id != 7 )  {
        return;
    }

    // Show a friendly green notice, and allow it to be dismissed (it will re-appear if the page is reloaded though).
    $class = 'notice notice-success is-dismissible';

    // Customize the HTML to  fit your preferences.
    $message = '<p><a target="_blank" href="'.admin_url().'themes.php?page=ot-theme-options">:::Click here! to edit homepage content :::</a></p>';

    printf( '<div class="%1$s"><div class="homepageEditContent">%2$s</div></div>', $class, $message ); 
}
add_action( 'admin_notices', 'homepage_edit_notice' );
