<?php
defined('ABSPATH') || exit;
add_action('admin_init', 'custom_theme_options', 1 );
function custom_theme_options() {
						$saved_settings = get_option('option_tree_settings', array() );
						$custom_settings = array(
							'sections' => array(
							array(
							'id' => 'header',
							'title' => 'Header'
							),
							array(
							'id' => 'homepage',
							'title' => 'Home'
							),
							array(
							'id' => 'footer',
							'title' => 'Footer'
							)
					
							),
							'settings' => array(
								array(
								'id' => '_scla_header_t0',
								'label' => 'Header :',
								'type' => 	'tab',
								'section' => 'header'
								),
								array(
								'id' => '_scla_header_logo',
								'label' => 'Logo :',
								'type' => 	'upload',
								'section' => 'header'
								),
								array(
								'id' => '_scla_home_t0',
								'label' => 'Welcome Section :',
								'type' => 	'tab',
								'section' => 'homepage'
								),
								array(
								'id' => '_scla_home_left_heading',
								'label' => 'Heading : Left',
								'type' => 	'text',
								'section' => 'homepage'
								),
								array(
								'id' => '_scla_home_left_subheading',
								'label' => 'Sub-Heading : Left',
								'type' => 	'text',
								'section' => 'homepage'
								),
								array(
								'id'          => '_scla_home_left_list',
						        'label'       => 'Add List Item : Left',
						        'type'        => 'list-item',
						        'section' => 'homepage',
						        'settings'    => array(
						            array(
						            'id'        => '_scla_home_left_list_title',
						            'label'     => 'Write : ',
						            'type'      => 'text'
						            	),
									)          
						     	),
								array(
									'id' => '_scla_home_right_image',
									'label' => 'Upload Image : Right',
									'type' => 	'upload',
									'section' => 'homepage'
									),
								array(
								'id' => '_scla_home_t1',
								'label' => 'Event Section :',
								'type' => 	'tab',
								'section' => 'homepage'
								),
								array(
								'id' => '_scla_home_event_title',
								'label' => 'Event title :',
								'type' => 	'text',
								'section' => 'homepage'
								),
								array(
								'id' => '_scla_home_t4',
								'label' => 'Call-to-action Section :',
								'type' => 	'tab',
								'section' => 'homepage'
								),
								array(
								'id' => '_scla_home_calltoaction_heading',
								'label' => 'Heading :',
								'type' => 	'text',
								'section' => 'homepage'
								),
								array(
								'id' => '_scla_home_calltoaction_subheading',
								'label' => 'Sub-Heading :',
								'type' => 	'text',
								'section' => 'homepage'
								),
								array(
								'id' => '_scla_home_t2',
								'label' => 'Sponsor Section :',
								'type' => 	'tab',
								'section' => 'homepage'
								),
								array(
								'id' => '_scla_home_sponsor_heading',
								'label' => 'Sponsor Heading :',
								'type' => 	'text',
								'section' => 'homepage'
								),
								array(
								'id' => '_scla_home_sponsor_subheading',
								'label' => 'Sponsor Sub-Heading :',
								'type' => 	'text',
								'section' => 'homepage'
								),
								/*
								array(
								'id' => '_scla_home_sponsor_gallery',
								'label' => 'Sponsor Gallery :',
								'type' => 	'gallery',
								'section' => 'homepage'
								),
								*/
								array(
								'id' => '_scla_home_t3',
								'label' => 'Executive Member Section :',
								'type' => 	'tab',
								'section' => 'homepage'
								),
								array(
								'id' => '_scla_home_member_heading',
								'label' => 'Executive Member Heading :',
								'type' => 	'text',
								'section' => 'homepage'
								),
								array(
								'id' => '_scla_footer_logo',
								'label' => 'Upload footer logo :',
								'type' => 	'upload',
								'section' => 'footer'
								),
								array(
								'id' => '_scla_footer_copyright',
								'label' => 'Copyright text :',
								'type' => 	'text',
								'section' => 'footer'
								),
	
							)	
						);
						

		if (
			$saved_settings !== $custom_settings ) {
			update_option('option_tree_settings', $custom_settings );
			}
} 
							
							
?>							