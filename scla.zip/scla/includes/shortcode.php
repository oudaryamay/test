<?php
/*Homepage template files*/
function homepage_shortcode( $attr ) {
    ob_start();
    get_template_part( 'tpl/home/slider', 'home' );
	get_template_part( 'tpl/home/welcome', 'home' ); 
	get_template_part( 'tpl/home/event', 'home' ); 
	get_template_part( 'tpl/home/calltoaction', 'home' );
	get_template_part( 'tpl/home/sponsor', 'home' ); 
	get_template_part( 'tpl/home/committee', 'home' );
    return ob_get_clean();
}
add_shortcode( 'home', 'homepage_shortcode' );

/*Membership plans*/
function membership_plan_shortcode( $attr ) {
    ob_start();
    get_template_part( 'tpl/membership', 'plan' );
    return ob_get_clean();
}
add_shortcode( 'membership', 'membership_plan_shortcode' );

/*All events*/
function all_events_shortcode( $attr ) {
    ob_start();
    get_template_part( 'tpl/event', 'list' );
    return ob_get_clean();
}
add_shortcode( 'events', 'all_events_shortcode' );

/*All events*/
function all_sponsor_shortcode( $attr ) {
    ob_start();
    get_template_part( 'tpl/home/sponsor', 'home' ); 
    return ob_get_clean();
}
add_shortcode( 'sponsors', 'all_sponsor_shortcode' );

/*All member*/
function all_members_shortcode( $attr ) {
    ob_start();
    get_template_part( 'tpl/member', 'list' ); 
    return ob_get_clean();
}
add_shortcode( 'members', 'all_members_shortcode' );

/*All user*/
function all_users_shortcode( $attr ) {
    ob_start();
    get_template_part( 'tpl/user', 'list' ); 
    return ob_get_clean();
}
add_shortcode( 'users', 'all_users_shortcode' );

/*Search user*/
function search_users_shortcode( $attr ) {
    ob_start();
    get_template_part( 'tpl/user', 'search' ); 
    return ob_get_clean();
}
add_shortcode( 'Search_users', 'search_users_shortcode' );