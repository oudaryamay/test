<?php
defined('ABSPATH') || exit;
/* Custom slider Post */
register_post_type( 'scla-slider', /* seen at the URL as a parameter and a unique id for the custom post */
  array(
   'labels' => array(
    'name' => __( 'Slider','Slider' ), /* The Label of the custom post */
    'singular_name' => __( "Slider", 'scla' ), /* The Label of the custom post */
    'add_new'            => __( 'Add New', 'Slider', 'scla' ),
    'add_new_item'       => __( 'Add New Slider', 'scla' ),
    'new_item'           => __( 'New Slider', 'scla' ),
    'edit_item'          => __( 'Edit Slider', 'scla' ),
    'view_item'          => __( 'View Slider', 'scla' ),
    'all_items'          => __( 'All Slider', 'scla' ),
    'update_item'           => __( 'Update Slider', 'scla' ),
    'search_items'          => __( 'Search Slider', 'scla' ),
    'not_found'             => __( 'No Slider found', 'scla' ),
    'featured_image'        => __( 'Slider Image', 'scla' ),
    'set_featured_image'    => __( 'Set Slider image', 'scla' ),
    'remove_featured_image' => __( 'Remove Slider image', 'scla' ),
    'use_featured_image'    => __( 'Use as Slider image', 'scla' ),
    'insert_into_item'      => __( 'Insert into Slider', 'scla' ),
    'uploaded_to_this_item' => __( 'Uploaded to this Slider image', 'scla' ),
   ),
   'public' => true,
   'menu_icon'   => 'dashicons-images-alt2',
   'has_archive' => false,
   'rewrite' => array('slug' => 'scla-slider'), /* The slug of the custom post */
   'supports' => array( 'title','thumbnail','editor'), /* enable basic for text editing */
  )
 );
 function slider_change_title_text( $title ){
     $screen = get_current_screen();
 
     if  ( 'scla-slider' == $screen->post_type ) {
          $title = 'Enter slider title here';
     }
 
     return $title;
    }
     
add_filter( 'enter_title_here', 'slider_change_title_text' );
add_action('admin_head', 'slider_custom_admin_post_css');
function slider_custom_admin_post_css() {

    global $post_type;

    if ($post_type == 'scla-slider') {
        echo "<style>#edit-slug-box {display:none;}</style>";
    }
}
/* Custom team Post */

//register_post_type( 'scla-team', /* seen at the URL as a parameter and a unique id for the custom post */
 // array(
   //'labels' => array(
    //'name' => __( 'Member','Member' ), /* The Label of the custom post */
    //'singular_name' => __( "Member", 'scla' ), /* The Label of the custom post */
    //'add_new'            => __( 'Add New Member', 'Team', 'scla' ),
    //'add_new_item'       => __( 'Add New Member', 'scla' ),
    //'new_item'           => __( 'New Member', 'scla' ),
    //'edit_item'          => __( 'Edit Member', 'scla' ),
    //'view_item'          => __( 'View Member', 'scla' ),
    //'all_items'          => __( 'All Members', 'scla' ),
    //'update_item'           => __( 'Update Member', 'scla' ),
    //'search_items'          => __( 'Search member', 'scla' ),
    //'not_found'             => __( 'No member found', 'scla' ),
    //'featured_image'        => __( 'Member Image', 'scla' ),
    //'set_featured_image'    => __( 'Set member image', 'scla' ),
    //'remove_featured_image' => __( 'Remove member image', 'scla' ),
    //'use_featured_image'    => __( 'Use as member image', 'scla' ),
    //'insert_into_item'      => __( 'Insert into member', 'scla' ),
    //'uploaded_to_this_item' => __( 'Uploaded to this member image', 'scla' ),
   //),
   //'public' => true,
   //'menu_icon'   => 'dashicons-groups',
   //'has_archive' => false,
   //'rewrite' => array('slug' => 'scla-team'), /* The slug of the custom post */
   //'supports' => array( 'title','thumbnail', 'editor'), /* enable basic for text editing */
  //)
 //);

 function team_change_title_text( $title ){
     $screen = get_current_screen();
 
     if  ( 'scla-team' == $screen->post_type ) {
          $title = 'Write member name';
     }
 
     return $title;
    }
     
//add_filter( 'enter_title_here', 'team_change_title_text' );
/* member Taxonomy for Category */
function member_taxonomie() {
  register_taxonomy(
    'member_category',
    array( 'scla-team' ),
    array(  
      'public' => true,
      'show_ui' => true,
            'show_tagcloud' => true,
            'hierarchical' => true,
      'labels' => array(
        'name' => __( 'Member Category', 'scla' ),
        'singular_name' => __( 'Member Category', 'scla' )
      ),
    )
  );
}
//add_action( 'init', 'member_taxonomie', 0 );
/* Custom team Sponsor */
register_post_type( 'scla-sponsor', /* seen at the URL as a parameter and a unique id for the custom post */
  array(
   'labels' => array(
    'name' => __( 'Sponsor','Sponsor' ), /* The Label of the custom post */
    'singular_name' => __( "Sponsor", 'scla' ), /* The Label of the custom post */
    'add_new'            => __( 'Add New Sponsor', 'Sponsor', 'scla' ),
    'add_new_item'       => __( 'Add New Sponsor', 'scla' ),
    'new_item'           => __( 'New Sponsor', 'scla' ),
    'edit_item'          => __( 'Edit Sponsor', 'scla' ),
    'view_item'          => __( 'View Sponsor', 'scla' ),
    'all_items'          => __( 'All Sponsor', 'scla' ),
    'update_item'           => __( 'Update Sponsor', 'scla' ),
    'search_items'          => __( 'Search Sponsor', 'scla' ),
    'not_found'             => __( 'No Sponsor found', 'scla' ),
    'featured_image'        => __( 'Sponsor Image', 'scla' ),
    'set_featured_image'    => __( 'Set Sponsor image', 'scla' ),
    'remove_featured_image' => __( 'Remove Sponsor image', 'scla' ),
    'use_featured_image'    => __( 'Use as Sponsor image', 'scla' ),
    'insert_into_item'      => __( 'Insert into Sponsor', 'scla' ),
    'uploaded_to_this_item' => __( 'Uploaded to this Sponsor image', 'scla' ),
   ),
   'public' => true,
   'menu_icon'   => 'dashicons-money',
   'has_archive' => false,
   'rewrite' => array('slug' => 'scla-sponsor'), /* The slug of the custom post */
   'supports' => array( 'title','thumbnail'), /* enable basic for text editing */
  )
 );
 function sponsor_change_title_text( $title ){
     $screen = get_current_screen();
 
     if  ( 'scla-sponsor' == $screen->post_type ) {
          $title = 'Write sponsor name';
     }
 
     return $title;
    }
     
add_filter( 'enter_title_here', 'sponsor_change_title_text' );

add_action('admin_head', 'sponsor_custom_admin_post_css');
function sponsor_custom_admin_post_css() {

    global $post_type;

    if ($post_type == 'scla-sponsor') {
        echo "<style>#edit-slug-box {display:none;}</style>";
    }
}


