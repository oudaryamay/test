<?php
/**
 * Exclude products from a particular category on the shop page
 */
function custom_pre_get_posts_query( $q ) {

    $tax_query = (array) $q->get( 'tax_query' );

    $tax_query[] = array(
           'taxonomy' => 'product_cat',
           'field' => 'slug',
           'terms' => array( 'memberships' ), // Don't display products in the clothing category on the shop page.
           'operator' => 'NOT IN'
    );


    $q->set( 'tax_query', $tax_query );

}
add_action( 'woocommerce_product_query', 'custom_pre_get_posts_query' );

//remove category
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );

//remove breadcumb
remove_action( 'woocommerce_before_main_content','woocommerce_breadcrumb', 20, 0);

//Remove shop page title
add_filter( 'woocommerce_show_page_title' , 'woo_hide_page_title' );

function woo_hide_page_title() {
	
	return false;
	
}
//quantity field remove
function wc_remove_all_quantity_fields( $return, $product ) {
    return true;
}
add_filter( 'woocommerce_is_sold_individually', 'wc_remove_all_quantity_fields', 10, 2 );

//woo notice hide
add_filter( 'woocommerce_helper_suppress_admin_notices', '__return_true' );

//woo extra field
function wooc_extra_register_fields() {?>
       <p class="form-row form-row-first">
       <label for="reg_billing_first_name"><?php _e( 'First name', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
       <input type="text" class="input-text" name="billing_first_name" id="reg_billing_first_name" value="<?php if ( ! empty( $_POST['billing_first_name'] ) ) esc_attr_e( $_POST['billing_first_name'] ); ?>" required/>
       </p>
       <p class="form-row form-row-last">
       <label for="reg_billing_last_name"><?php _e( 'Last name', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
       <input type="text" class="input-text" name="billing_last_name" id="reg_billing_last_name" value="<?php if ( ! empty( $_POST['billing_last_name'] ) ) esc_attr_e( $_POST['billing_last_name'] ); ?>" required/>
       </p>
       <p class="form-row form-row-wide">
       <label for="reg_billing_phone"><?php _e( 'Phone', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
       <input type="text" class="input-text" name="billing_phone" id="reg_billing_phone" value="<?php if ( ! empty( $_POST['billing_phone'] ) ) esc_attr_e( $_POST['billing_phone'] ); ?>" required/>
       </p>
       <p class="form-row form-row-wide">
       <label for="billing_company"><?php _e( 'Firm', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
       <input type="text" class="input-text" name="billing_company" id="billing_company" value="<?php if ( ! empty( $_POST['billing_company'] ) ) esc_attr_e( $_POST['billing_company'] ); ?>" required/>
       </p>
       <p class="form-row form-row-wide">
       <label for="member_type"><?php esc_html_e( 'Member Type', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>

      Life Member <input type="checkbox" class="woocommerce-Input woocommerce-Input--checkbox input-checkbox" name="life_member" value="1" />
      
      Barristers <input type="checkbox" class="woocommerce-Input woocommerce-Input--checkbox input-checkbox" name="barristers" value="1" />

      Solicitors <input type="checkbox" class="woocommerce-Input woocommerce-Input--checkbox input-checkbox" name="solicitors" value="1" />

      Associates <input type="checkbox" class="woocommerce-Input woocommerce-Input--checkbox input-checkbox" name="associates" value="1" />

      Students <input type="checkbox" class="woocommerce-Input woocommerce-Input--checkbox input-checkbox" name="students" value="1" />
       </p>
       <div class="clear"></div>
       <?php
 }
 add_action( 'woocommerce_register_form_start', 'wooc_extra_register_fields' );

 /**

* register fields Validating.

*/

function wooc_validate_extra_register_fields( $username, $email, $validation_errors ) {

      if ( isset( $_POST['billing_first_name'] ) && empty( $_POST['billing_first_name'] ) ) {

             $validation_errors->add( 'billing_first_name_error', __( '<strong>Error</strong>: First name is required!', 'woocommerce' ) );

      }

      if ( isset( $_POST['billing_last_name'] ) && empty( $_POST['billing_last_name'] ) ) {

             $validation_errors->add( 'billing_last_name_error', __( '<strong>Error</strong>: Last name is required!', 'woocommerce' ) );

      }

      if ( isset( $_POST['billing_phone'] ) && empty( $_POST['billing_phone'] ) ) {

             $validation_errors->add( 'billing_phone_error', __( '<strong>Error</strong>: Phone number is required!', 'woocommerce' ) );

      }

       if ( isset( $_POST['billing_company'] ) && empty( $_POST['billing_company'] ) ) {

             $validation_errors->add( 'billing_company_error', __( '<strong>Error</strong>: Firm is required!', 'woocommerce' ) );

      }
         return $validation_errors;
}

add_action( 'woocommerce_register_post', 'wooc_validate_extra_register_fields', 10, 3 );

/**
* Below code save extra fields.
*/
function wooc_save_extra_register_fields( $customer_id ) {
  
      if ( isset( $_POST['billing_first_name'] ) ) {
             //First name field which is by default
             update_user_meta( $customer_id, 'first_name', sanitize_text_field( $_POST['billing_first_name'] ) );
             // First name field which is used in WooCommerce
             update_user_meta( $customer_id, 'billing_first_name', sanitize_text_field( $_POST['billing_first_name'] ) );
      }
      if ( isset( $_POST['billing_last_name'] ) ) {
             // Last name field which is by default
             update_user_meta( $customer_id, 'last_name', sanitize_text_field( $_POST['billing_last_name'] ) );
             // Last name field which is used in WooCommerce
             update_user_meta( $customer_id, 'billing_last_name', sanitize_text_field( $_POST['billing_last_name'] ) );
      }
      if ( isset( $_POST['billing_phone'] ) ) {
                 // Phone input filed which is used in WooCommerce
            update_user_meta( $customer_id, 'billing_phone', sanitize_text_field( $_POST['billing_phone'] ) );
      }

      if ( isset( $_POST['billing_company'] ) ) {
             // Firm input filed which is used in WooCommerce
             update_user_meta( $customer_id, 'billing_company', sanitize_text_field( $_POST['billing_company'] ) );
       }
  // Role input filed which is used in WooCommerce
     $role = array('life-member' 	=> $_POST['life_member'],
			                'barristers'  	=> $_POST['barristers'],
			                'solicitors'   	=> $_POST['solicitors'],
			                'associates'   	=> $_POST['associates'],
			                'students'   	=> $_POST['students'] 
			            	);

             update_user_meta( $customer_id, '_customer_role', $role );

    //Email status
    update_user_meta( $customer_id, '_email_publis_status', 1 ); 
    //phone status
    update_user_meta( $customer_id, '_phone_publis_status', 1 );         
 
}
add_action( 'woocommerce_created_customer', 'wooc_save_extra_register_fields' );

/* Add custom menu item and endpoint to WooCommerce My-Account page */

function my_custom_endpoints() {
    add_rewrite_endpoint( 'my-profile', EP_ROOT | EP_PAGES );
}

add_action( 'init', 'my_custom_endpoints' );

function my_custom_query_vars( $vars ) {
    $vars[] = 'my-profile';

    return $vars;
}

add_filter( 'query_vars', 'my_custom_query_vars', 0 );

function my_custom_flush_rewrite_rules() {
    flush_rewrite_rules();
}

add_action( 'after_switch_theme', 'my_custom_flush_rewrite_rules' );

function my_custom_my_account_menu_items( $items ) {
    $items = array(
        'dashboard'         => __( 'Dashboard', 'woocommerce' ),
        'orders'            => __( 'Orders', 'woocommerce' ),
        //'downloads'       	=> __( 'Downloads', 'woocommerce' ),
        'edit-address'    	=> __( 'Addresses', 'woocommerce' ),
        //'payment-methods' => __( 'Payment Methods', 'woocommerce' ),
        'edit-account'      => __( 'Edit Account', 'woocommerce' ),
        'my-profile'      	=> __( 'My Profile', 'woocommerce' ),
        'customer-logout'   => __( 'Logout', 'woocommerce' ),
    );

    return $items;
}

add_filter( 'woocommerce_account_menu_items', 'my_custom_my_account_menu_items' );

function my_custom_endpoint_content() {
      require( trailingslashit( get_template_directory() ) . 'woocommerce/myaccount/my-profile.php' );

}

add_action( 'woocommerce_account_my-profile_endpoint', 'my_custom_endpoint_content' );

//profile field that can only managable by admin
add_action( 'show_user_profile', 'show_extra_profile_fields_for_admin' );
add_action( 'edit_user_profile', 'show_extra_profile_fields_for_admin' );

function show_extra_profile_fields_for_admin( $user ) { 
  $user_id = $user->ID;

  $member = get_user_meta($user_id, '_member_type', true);
  $designation = get_user_meta($user_id, '_executive_member_designation', true);
  /*
  echo '<pre>';
  print_r($member);
  echo '</pre>';
  */
  ?>
    <h3 style="color: green">Member type</h3>
    <table class="form-table">
        <tr>
            <th><label for="member">Member</label></th>
            <td>
             Executive Member <input type="checkbox" class="woocommerce-Input woocommerce-Input--checkbox input-checkbox" name="executive_member" value="1"  <?php if (isset($member['executive_member'])) { echo $status = ($member['executive_member'] == 1) ? 'checked' : ''; } ?> />
             Commission Member <input type="checkbox" class="woocommerce-Input woocommerce-Input--checkbox input-checkbox" name="commission_member" value="1" <?php if (isset($member['commission_member'])) { echo $status = ($member['commission_member'] == 1) ? 'checked' : ''; } ?> />
             Member <input type="checkbox" class="woocommerce-Input woocommerce-Input--checkbox input-checkbox" name="member" value="1" <?php if (isset($member['member'])) { echo $status = ($member['member'] == 1) ? 'checked' : ''; } ?> />
            </td>
        </tr>

        <tr>
            <th><label for="member">Designation</label></th>
            <td>
            <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="executive_member_designation" value="<?php if (isset($designation)) {echo  $designation; } ?>" />
            </td>
        </tr>
    </table>
<?php }

add_action( 'personal_options_update', 'save_extra_profile_fields_for_admin' );
add_action( 'edit_user_profile_update', 'save_extra_profile_fields_for_admin' );

function save_extra_profile_fields_for_admin( $user_id ) {
    if ( !current_user_can( 'administrator', $user_id ) )
        return false;

    $member_type = array( 'executive_member'     => $_POST['executive_member'],
                          'commission_member'    => $_POST['commission_member'],
                          'member'               => $_POST['member']
                         );
    $member_designation = sanitize_text_field( $_POST['executive_member_designation']);
    update_usermeta( $user_id, '_member_type', $member_type);
    update_usermeta( $user_id, '_executive_member_designation', $member_designation);
}

/* This removes the function that redirects customers to the shop page */
function enable_author_archives_for_customers() {
  remove_action('template_redirect', 'wc_disable_author_archives_for_customers');
}
add_action( 'after_setup_theme', 'enable_author_archives_for_customers' );

add_filter( 'woocommerce_product_tabs', 'woo_remove_product_tabs', 98 );

function woo_remove_product_tabs( $tabs ) {

    //unset( $tabs['description'] );        // Remove the description tab
    unset( $tabs['reviews'] );      // Remove the reviews tab
    return $tabs;
}