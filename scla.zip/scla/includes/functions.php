<?php
/**
 * Loads custom functions
 */
require( trailingslashit( get_template_directory() ) . 'includes/custom-functions.php' );
/**
 * Loads script and styles
 */
require( trailingslashit( get_template_directory() ) . 'includes/style-script.php' );
/**
 * Loads custom login
 */
require( trailingslashit( get_template_directory() ) . 'includes/custom-login.php' );
/**
 * Loads custom post
 */
require( trailingslashit( get_template_directory() ) . 'includes/custom-post.php' );
/**
 * Loads shortcode
 */
require( trailingslashit( get_template_directory() ) . 'includes/shortcode.php' );
/**
 * Loads Theme Options
 */
require( trailingslashit( get_template_directory() ) . 'static/ot-loader.php' );
require( trailingslashit( get_template_directory() ) . 'includes/theme-options.php' );
require( trailingslashit( get_template_directory() ) . 'includes/meta-boxes.php' );
/**
 * Loads woocommerce functions
 */
require( trailingslashit( get_template_directory() ) . 'includes/woo.php' );