<?php get_header();

if ( have_posts() ) : while ( have_posts() ) : the_post();
	if ( get_post_type( get_the_ID() ) == 'scla-team' ) {
	?>
<div class="col-sm-4">
	<div class="membrprflpic">
		<?php
		$featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full'); 
		if ($featured_img_url != null) {
		echo '<img src="'.esc_url($featured_img_url).'" alt="" border="0">';
		} else {
		echo '<img src="'.get_template_directory_uri().'/assets/images/executive-noimage.jpg" alt="" border="0">';
		}
		?>
	</div>
</div><!-- left part closed -->
<div class="col-sm-8 memberdetail">
	<h3 class="membername"><?php echo get_the_title(); ?></h3>
		<?php   // Get terms for post
		 $member_cats = get_the_terms( $post->ID , 'member_category' );
		 if ( $member_cats != null ){
		 $i=1;
		 foreach( $member_cats as $member_cat ) {
		 $class=($i != 1) ? 'designation' : '';
		 echo '<h4 class="membersubname '.$class.'">'.$member_cat->name.'</h4>';
		 unset($member_cat);
		 $i++;
			} 
		} 
		?>
	
		<?php
		$phone_state=get_post_meta(get_the_ID(), '_scla_team_phone_onoff', true);
		$phone=get_post_meta(get_the_ID(), '_scla_team_phone', true);

		$email_state=get_post_meta(get_the_ID(), '_scla_team_email_onoff', true);
		$email=get_post_meta(get_the_ID(), '_scla_team_email', true);

		$url=get_post_meta(get_the_ID(), '_scla_team_website', true);
		$url_lnk='http://www.'.$url;

		if($phone_state == 'on' || $email_state == 'on' || $url != null) :
		?>
	<ul class="meminfolist">
		<?php
		if ($phone_state == 'on' && $phone != null) :
		echo '<li><a href="tel: '.$phone.'"><img src="'.get_template_directory_uri().'/assets/images/phone-icon.png" alt="" border="0"><span>'.$phone.'</span></a></li>';
		endif;

		if ($email_state == 'on' && $email != null) :
		echo '<li><a href="mailto: '.$email.'"><img src="'.get_template_directory_uri().'/assets/images/envelop-icon.png" alt="" border="0"><span>'.$email.'</span></a></li>';
		endif;

		if($url != null):
		echo '<li><a target="_blank" href="'.$url_lnk.'"><img src="'.get_template_directory_uri().'/assets/images/glob-icon.png" alt="" border="0"><span>'.$url.'</span></a></li>';
		endif;
		?>
	</ul>
	<?php endif; ?>
	<?php echo get_the_content(); ?>
	
	<?php
	$firm=get_post_meta(get_the_ID(), '_scla_team_firm', true);
	if($firm != null) :
	echo '<div class="infoblck">
		'.$firm.'
	</div>';
	endif;
	?>
	
	<?php
	$areas=get_post_meta(get_the_ID(), '_scla_team_areas_of_law', true);
	if($areas != null) :
	echo '<div class="infoblck border-none">
		<label>AREAS OF LAW</label>
		<ul>';
	foreach($areas as $area) :
	echo '<li>'.$area['_scla_team_areas_of_law_item'].'</li>';
	endforeach;

	echo '</ul>
	</div>';
   endif;
	?>
</div><!-- right part closed -->
	<?php
	} else {
	the_content();	
	}
	endwhile; endif;

get_footer(); ?>