<!DOCTYPE html>
<html <?php language_attributes(); ?> dir="ltr" lang="en">
<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="author" content="" />

<!-- Page Title -->
<?php if (is_front_page() ) { ?>
<title><?php echo bloginfo( 'name' ); ?></title>
<?php } else { ?>
<title><?php wp_title(''); echo ' | ';  bloginfo( 'name' ); ?></title>
<?php } ?>

<!-- Favicon and Touch Icons -->
<!--<link href="favicon.png" rel="shortcut icon" type="image/png">-->

<!-- import web fonts -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<?php wp_head(); ?>
</head>
<html <?php language_attributes(); ?> dir="ltr" lang="en">
<body class="woocommerce animsition">
<?php get_template_part( 'tpl/nav', 'menu' ); ?>
<?php
if (! is_front_page()) {
get_template_part( 'tpl/inner', 'banner' );
get_template_part( 'tpl/wrapper', 'start' );
}
?>