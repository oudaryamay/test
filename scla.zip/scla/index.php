<?php
//I am not the hero but will be!