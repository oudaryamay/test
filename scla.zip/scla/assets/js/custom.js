// JavaScript Document

/* =======================================================================================
Short code list ------------------------------------------------------------------------------

-- window resize function
   -- browser reload on window resize

-- Document ready function
   -- class add for mobile sponsor slider script
   -- class add for mobile executive slider script
   -- Slick script short script
   -- member type list dropdown for mobile

==========================================================================================*/



/*=========================== window resize script start ============================*/
jQuery(window).resize(function(){

  windowsize=jQuery(window).width();

  if(windowsize>1199){
    //location.reload();
    setTimeout(function(){
      window.location.reload();
    });
  }

});
/*=========================== window resize script ended ============================*/



/*============================== Document ready script start ==============================*/
jQuery(document).ready(function() {
jQuery(".memberTabArea .nav-tabs").addClass("memberTypelistMobileView");

  var windowsize=jQuery(window).width();


/* ============= class add for mobile slider script start ============ */
  if(windowsize <= 1023){
    jQuery(".sponsors-slider").addClass("sponsors-mobile-slider");
    jQuery(".executive-slider").addClass("executive-mobile-slider");
  }else{
    jQuery(".sponsors-slider").removeClass("sponsors-mobile-slider");
    jQuery(".executive-slider").removeClass("executive-mobile-slider");
  }

  if(windowsize <= 991){
    memberTypelistDropdownToggle();
    userAccoutNavDropdownToggle();
    jQuery(".fltrarea").addClass("mobile");
  }else{
    jQuery(".fltrarea").removeClass("mobile");
  }
/* ============= class add for mobile slider script ended ============ */



/*==========================================================================================
Slick js short script start 
=============================================================================================*/	
	
  /* ================== home banner script ====================*/
  jQuery('.home-slider').slick({
    fade: true, dots: false, infinite: true, arrows: false, slidesToShow: 1, slidesToScroll: 1
  });

  /* ===================== event slider script ===============*/
  jQuery('.event-slider').slick({
		dots: false, arrows:false, infinite: false, speed:300, slidesToShow: 3, slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: { slidesToShow: 2, slidesToScroll: 1 }
      },
      {
        breakpoint: 992,
        settings: { slidesToShow: 2, slidesToScroll: 1 }
      },
      {
        breakpoint: 680,
        settings: { slidesToShow: 1, slidesToScroll: 1 }
      }
    ]
  }); 

  /* ==================== sponsors script ======================*/
  jQuery(".sponsors-mobile-slider").slick({
    dots: false, arrows:false, infinite: false, speed:300, slidesToShow: 3, slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: { slidesToShow: 3, slidesToScroll: 1 }
      },
      {
        breakpoint: 600,
        settings: { slidesToShow: 2, slidesToScroll: 1 }
      },
      {
        breakpoint: 680,
        settings: { slidesToShow: 1, slidesToScroll: 1 }
      },
      {
        breakpoint: 480,
        settings: { slidesToShow: 1, slidesToScroll: 1 }
      }
    ]
  });

  /* ==================== executive script ======================*/
  jQuery(".executive-mobile-slider").slick({
    dots: false, arrows:false, infinite: false, speed:300, slidesToShow: 3, slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: { slidesToShow: 3, slidesToScroll: 1 }
      },
      {
        breakpoint: 992,
        settings: { slidesToShow: 2, slidesToScroll: 1 }
      },
      {
        breakpoint: 680,
        settings: { slidesToShow: 1, slidesToScroll: 1 }
      }
    ]
  });


  /* ==================== executive script ======================*/
  jQuery(".related-product-slider").slick({
    dots: false, arrows:false, infinite: false, speed:300, slidesToShow: 3, slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: { slidesToShow: 3, slidesToScroll: 1 }
      },
      {
        breakpoint: 992,
        settings: { slidesToShow: 2, slidesToScroll: 1 }
      },
      {
        breakpoint: 680,
        settings: { slidesToShow: 1, slidesToScroll: 1 }
      }
    ]
  });
	  

/*==========================================================================================
 Slick js short script end here 
=============================================================================================*/



/*==========================================================================================
Member search popup for mobile script start 
=============================================================================================*/ 

$(".searchMobBtn").click(function(){
  $(".fltrarea.mobile").toggleClass("open");
  $(".fltrarea.mobile").prepend('<a class="closeFilter">Close</a>');
  $(".closeFilter").click(function(){
    $(".fltrarea.mobile").toggleClass("open");
    $(this).remove();
  });
});

$(".applyFliterBtn").click(function(){
  setTimeout(function(){
      $(".fltrarea.mobile").toggleClass("open");
      $(".closeFilter").remove();
  }, 1000);
});
/*==========================================================================================
Member search popup for mobile script closed
=============================================================================================*/ 




});
/*============================== Document ready script ended ==============================*/



function atleast_onecheckbox(e) {
  if ($("input[type=checkbox]:checked").length === 0) {
      e.preventDefault();
      alert('Please select at-least one member type!');
      return false;
  }
}

function atleast_onecheckbox_myprofile(e) {
  if ($("input[type=checkbox]:checked").length === 0) {
      e.preventDefault();
      alert('Please select at-least one member type!');
      return false;
  }
}

function memberTypelistDropdownToggle() {
  jQuery(".memberTypelistMobileView").click(function(){
    $(this).toggleClass("show");
  }); 
}


function userAccoutNavDropdownToggle() {
  $(".woocommerce-MyAccount-navigation li.is-active").addClass("fix");
  $(".woocommerce-MyAccount-navigation li.is-active").click(function(){
    $(".woocommerce-MyAccount-navigation").toggleClass("open");
  });
}






