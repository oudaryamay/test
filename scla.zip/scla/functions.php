<?php
/*Media handler*/
require_once(ABSPATH . "wp-admin" . '/includes/image.php');
require_once(ABSPATH . "wp-admin" . '/includes/file.php');
require_once(ABSPATH . "wp-admin" . '/includes/media.php');
//Theme function
require( trailingslashit( get_template_directory() ) . 'includes/functions.php' );
